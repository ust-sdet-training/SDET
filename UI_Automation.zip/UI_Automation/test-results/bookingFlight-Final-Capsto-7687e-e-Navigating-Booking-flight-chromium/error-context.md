# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: bookingFlight.spec.ts >> Final Capstone: TripStack Scenario >> @smoke Navigating & Booking flight
- Location: tests\bookingFlight.spec.ts:15:9

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Matcher error: received value must be a number or bigint

Received has type:  object
Received has value: Promise {}
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - banner [ref=e2]:
    - generic [ref=e3]:
      - link "TripStack" [ref=e4] [cursor=pointer]:
        - /url: /
      - navigation "Primary" [ref=e5]:
        - link "Flights" [ref=e6] [cursor=pointer]:
          - /url: /flights/search
        - link "Buses" [ref=e7] [cursor=pointer]:
          - /url: /buses/search
        - link "My Trips" [ref=e8] [cursor=pointer]:
          - /url: /my-trips
        - link "Log out" [ref=e9] [cursor=pointer]:
          - /url: /logout
  - main [ref=e10]:
    - heading "My Trips" [level=1] [ref=e11]
    - paragraph [ref=e12]: Your bookings and their current status.
    - generic [ref=e14]:
      - generic [ref=e15]:
        - generic [ref=e16]:
          - generic [ref=e17]: TS-1013-0001
          - generic [ref=e18]: CONFIRMED
        - generic [ref=e19]: flight · seats 1C
      - generic [ref=e20]:
        - generic [ref=e21]: ₹5053.94
        - button "Cancel" [ref=e23] [cursor=pointer]
  - contentinfo [ref=e24]:
    - generic [ref=e25]:
      - generic [ref=e26]: © TripStack — a demo travel marketplace for SDET training.
      - generic [ref=e27]: Flights · Buses · Seat selection · Secure checkout
```

# Test source

```ts
  1  | import { Page, expect} from "@playwright/test";
  2  | import { MyTripsPage } from "../pages/MyTripsPage";
  3  | import { EnvCheck } from "../support/EnvCheck";
  4  | 
  5  | export class MyTripsFlow{
  6  |     private readonly mytripsPage: MyTripsPage;
  7  | 
  8  | 
  9  |     constructor(private readonly page: Page){
  10 |         this.mytripsPage = new MyTripsPage(page);
  11 | 
  12 |     }
  13 |     async verifyTicketisBooked(){
> 14 |         await expect((await this.mytripsPage.getBookingCard()).count()).toBeGreaterThan(0);
     |                                                                         ^ Error: expect(received).toBeGreaterThan(expected)
  15 |     }
  16 | 
  17 |     async verifyBookingTitle(pnr: string){
  18 |         await expect(await this.mytripsPage.getBookingTitle()).toBeVisible();
  19 |         await expect(await this.mytripsPage.getBookingTitle()).toContainText(pnr);
  20 |     }
  21 | 
  22 |     async verifyBookingStatus(status: string){
  23 |         await expect(await this.mytripsPage.getyBookingStatus()).toBeVisible();
  24 |         await expect(await this.mytripsPage.getyBookingStatus()).toContainText(status);
  25 |     }
  26 | 
  27 |     async verifyBookingSeat(seat: string){
  28 |         await expect(await this.mytripsPage.getBookingSeat()).toBeVisible();
  29 |         await expect(await this.mytripsPage.getBookingSeat()).toContainText(seat);
  30 |     }
  31 | }
```